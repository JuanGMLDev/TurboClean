package com.turboclean.controllers;

import com.turboclean.models.Service;
import com.turboclean.services.ServiceService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ServiceDetailsController {
    // Componentes.
    @FXML
    private TextField nameField;
    @FXML
    private TextField statusField;
    @FXML
    private TextField typeField;

    // Atributo privado
    private final ServiceService serviceService = new ServiceService();

    // Métodos públicos com anotação FXML
    @FXML
    private void search() {
        String name = nameField.getText();
        Service service = serviceService.getServiceByUserName(name);

        if (service != null) {
            statusField.setText(service.getStatus());
            typeField.setText(service.getServiceType());
        } else {
            System.out.println("Serviço não encontrado");
        }
    }

    @FXML
    private void update() {
        String name = nameField.getText();
        String status = statusField.getText();
        String serviceType = typeField.getText();

        Service service = new Service(name, serviceType, status);
        serviceService.updateService(service);
        System.out.println("Status atualizado com sucesso");
    }

    @FXML
    private void goBack(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Home.fxml", event);
    }

    // Métodos privados
    private void openPage(String fxmlFile, javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void delete() {
        String name = nameField.getText();
        serviceService.deleteService(name);
        System.out.println("Serviço deletado com sucesso");
    }
}
