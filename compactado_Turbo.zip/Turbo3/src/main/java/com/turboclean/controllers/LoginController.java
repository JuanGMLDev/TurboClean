package com.turboclean.controllers;

import com.turboclean.services.UserService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    // Componente
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;

    // Atributo privado
    private final UserService userService = new UserService();

    // Métodos públicos com anotação FXML
    @FXML
    private void login() throws IOException {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (userService.authenticateUser(username, password)) {
            System.out.println("Seja bem-vindo, "+username+"!");
        } else {
            // Autenticação falhou
            System.out.println("Nome ou senha inválidos");
            Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
            dialogoInfo.setTitle("Erro");
            dialogoInfo.setHeaderText("Senha ou usuário inválidos!");
            dialogoInfo.setContentText("Verifique suas informações e tente novamente!");
            dialogoInfo.showAndWait();
        }
    }

    @FXML
    private void goBack(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Home.fxml", event);
    }

    // Métodos privados
    private void openPage(String fxmlFile, javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}

