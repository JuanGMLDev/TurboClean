package com.turboclean.models;

public class Service {
    // Atributos privados
    private String userName;
    private String serviceType;
    private String status;

    // Construtor público
    public Service(String userName, String serviceType, String status) {
        this.userName = userName;
        this.serviceType = serviceType;
        this.status = status;
    }

    // Métodos públicos (getters e setters)
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
