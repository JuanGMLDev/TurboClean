package com.turboclean.controllers;

import com.turboclean.models.Service;
import com.turboclean.services.ServiceService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class CreateServiceController { //Declaração da classe controladora de Create Service
    // Textfield: Componente.
    @FXML
    private TextField usernameField;

    // Atributo privado
    private final ServiceService serviceService = new ServiceService();

    // Métodos privados com anotação FXML
    @FXML
    private void createSimpleWash() {
        createService("Lavagem Simples");
    }

    @FXML
    private void createFullWash() {
        createService("Lavagem Completa");
    }

    @FXML
    private void createDetailedWash() {
        createService("Lavagem Detalhada");
    }

    @FXML
    private void goBack(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Home.fxml", event);
    }

    // Métodos privados
    private void openPage(String fxmlFile, javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    private void createService(String serviceType) {
        String username = usernameField.getText();
        Service service = new Service(username, serviceType, "Pendente");
        serviceService.createService(service);
        System.out.println("Serviço de: " + username + " criado com sucesso.");
    }
}
