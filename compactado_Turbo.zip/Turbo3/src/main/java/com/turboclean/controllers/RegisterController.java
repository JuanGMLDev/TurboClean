package com.turboclean.controllers;

import com.turboclean.models.User;
import com.turboclean.services.UserService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class RegisterController {
    // Componentes privados com anotação FXML
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;

    // Atributo privado
    private final UserService userService = new UserService();

    // Métodos públicos com anotação FXML
    @FXML
    private void register() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        User user = new User(username, password);
        userService.registerUser(user);
        System.out.println("Usuário registrado com sucesso");
        Alert dialogoInfo = new Alert(Alert.AlertType.INFORMATION);
        dialogoInfo.setTitle("Sucesso!");

        dialogoInfo.showAndWait();
    }

    @FXML
    private void goBack(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Home.fxml", event);
    }

    // Método privado
    private void openPage(String fxmlFile, javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
