package com.turboclean.models;

public class User {
    // Atributos privados
    private String name;
    private String password;

    // Construtor público
    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }

    // Métodos públicos (getters e setters)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
