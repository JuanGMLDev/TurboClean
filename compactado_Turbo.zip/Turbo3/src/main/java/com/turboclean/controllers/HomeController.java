package com.turboclean.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.Node;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController {
// Métodos de acessar outras janelas:
    @FXML
    private void goToRegister(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Register.fxml", event);
    }

    @FXML
    private void goToLogin(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/Login.fxml", event);
    }

    @FXML
    private void goToServiceDetails(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/ServiceDetails.fxml", event);
    }

    @FXML
    private void goToCreateService(javafx.event.ActionEvent event) throws IOException {
        openPage("/fxml/CreateService.fxml", event);
    }
// Método auxiliar, oq faz o codigo rodar
    private void openPage(String fxmlFile, javafx.event.ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
        Parent root = loader.load();

        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
