package com.turboclean.services;

import com.turboclean.db.Database;
import com.turboclean.models.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServiceService {

    // Métodos públicos
    public void createService(Service service) {
        try (Connection connection = Database.getConnection()) {
            String query = "INSERT INTO services (user_name, service_type, status) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, service.getUserName());
            statement.setString(2, service.getServiceType());
            statement.setString(3, service.getStatus());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Service getServiceByUserName(String userName) {
        try (Connection connection = Database.getConnection()) {
            String query = "SELECT * FROM services WHERE user_name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, userName);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return new Service(
                        resultSet.getString("user_name"),
                        resultSet.getString("service_type"),
                        resultSet.getString("status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateService(Service service) {
        try (Connection connection = Database.getConnection()) {
            String query = "UPDATE services SET status = ?, service_type = ? WHERE user_name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, service.getStatus());
            statement.setString(2, service.getServiceType());
            statement.setString(3, service.getUserName());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteService(String userName) {
        try (Connection connection = Database.getConnection()) {
            String query = "DELETE FROM services WHERE user_name = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, userName);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
